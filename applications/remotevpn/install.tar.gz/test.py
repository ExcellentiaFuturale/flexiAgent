#! /usr/bin/python


with open('/etc/openvpn/server/openvpn-status.log', 'r') as logfile:
    response = {
        'users': {}
    }

    status = logfile.read().splitlines()
    routing_table_idx = status.index("ROUTING TABLE")
    global_stats_idx = status.index("GLOBAL STATS")

    client_list = status[:routing_table_idx]
    for line in client_list[3:]:
        # line = 'shneorp@flexiwan.com ,192.168.1.1:57662,22206,13194,2021-12-22 11:57:33'
        fields = line.split(',')
        username = fields[0]

        response['users'][username] = {
            'Common Name': username,
            'Real Address': fields[1],
            'Bytes Received':  fields[2],
            'Bytes Sent': fields[3],
            'Connected Since': fields[4],
        }

    routing_table = status[routing_table_idx:global_stats_idx]
    for line in routing_table[2:]:
        # line = '50.50.50.2,shneorp@flexiwan.com ,192.168.1.1:1052,2021-12-22 11:57:33'
        fields = line.split(',')
        username = fields[1]
        if username in response['users']:
            response['users'][username]['Virtual Address'] = fields[0]

    print(response)

